<?php




echo "<pre>";
var_dump($_POST);
echo "</pre>";

echo "<pre>";
var_dump($_SESSION);
echo "</pre>";

echo "<pre>";
var_dump($_GET);
echo "</pre>";