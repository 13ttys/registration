<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User</title>
    <base href="<?php echo BASE_URL; ?>">
    <link rel="stylesheet" href="/css/iframe.css">
</head>
<body>
    <div id="test">Another page for Users! 1234567</div>


</body>
</html>